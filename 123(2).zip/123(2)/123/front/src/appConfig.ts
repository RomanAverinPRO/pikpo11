const appConfig = {
  backendProtocol: 'http',
  backendAddress: 'localhost:8080'
}

export default appConfig;