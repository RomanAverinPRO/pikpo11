import CustomSpinner from "./CustomSpinner";
export default CustomSpinner;