import AdminProps from "./Admin";
export default AdminProps;